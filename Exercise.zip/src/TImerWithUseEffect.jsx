import React, { useState, useEffect } from 'react';
const TImerWithUseEffect = () => {
    const [time, setTime] = useState(0); // Initial time set to 10 seconds
    useEffect(() => {
        // Set up interval to decrease time every second
        const interval = setInterval(() => {
            setTime((prevTime) => {
                if (prevTime === 100) clearInterval(interval); // Stop timer at 0
                return prevTime + 1;
            });
        }, 1000);
        // Cleanup interval when component unmounts or time reaches 0
        return () => clearInterval(interval);
    }, []); // Empty dependency array ensures this effectruns only once when the component mounts
    return (
        <div>
            <h2>Countdown: {time} seconds</h2>
            <button onClick={() => { clearInterval(0) }}>got to 0</button>
        </div >
    );
};
export default TImerWithUseEffect;