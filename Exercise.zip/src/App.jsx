import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import ColorPicker from './ColorPIcker'

function App() {
  return (
    <>
      <h1>Welcome To React Exercises</h1>
      <h2>Provide Exercise name to params</h2>
    </>
  )
}

export default App
